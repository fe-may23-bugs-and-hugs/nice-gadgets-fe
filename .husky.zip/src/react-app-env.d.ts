declare module '*.png';
declare module '*.svg';
declare module '*.jpg';
declare module '*.gif';
