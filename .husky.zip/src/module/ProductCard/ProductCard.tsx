import { DivElement } from './ProductCard.styled';

export const ProductCard = () => {
  return (
    <DivElement />
  );
};
