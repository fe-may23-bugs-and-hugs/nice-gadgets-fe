import styled from 'styled-components';

export const DivElement = styled.div`

`;
