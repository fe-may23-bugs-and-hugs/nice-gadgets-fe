export const Favorites = () => {
  return <h2>Favorites</h2>;
};
