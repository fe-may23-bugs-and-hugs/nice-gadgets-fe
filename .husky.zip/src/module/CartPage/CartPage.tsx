/* eslint-disable no-unused-vars */
/* eslint-disable no-console */
import React, { useState, useContext, useEffect } from 'react';
import { Icon, IconSprite } from '../shared/Sprites';
import { ContentLayout } from '../shared/ContentLayout';
import CartPageModal from './CartPageModal';
import { BackButton } from '../shared/BackButton/';
import {
  CartContainer,
  CartHeader,
  CartList,
  CartSummary,
  TotalPrice,
  TotalItems,
  CartCheckout,
  CartEmpty,
  ModalIconClose,
  BackButtonContainer,
} from './CartPage.styled';
import { CartContext } from '../../context';
import { CartItemPage } from './CartItemPage';

export const CartPage: React.FC = () => {
  const { cartProducts } = useContext(CartContext);
  const [showModal, setShowModal] = useState(false);

  const handleToggle = () => {
    setShowModal(!showModal);
  };

  console.log(cartProducts);

  const [totalItems, setTotalItems] = useState<null | number>(null);
  const [totalPrice, setTotalPrice] = useState();

  useEffect(() => {
    setTotalItems(cartProducts.length);
  }, [cartProducts]);

  // const calculateTotal = () => {
  //   const result = cartProducts.reduce(
  //     (acc, product) => {
  //       const { priceDiscount } = product;
  //       const quantity = 1;
  //       const oneItemPrice = quantity * priceDiscount;

  //       return {
  //         totalItems: acc.totalItems + quantity,
  //         totalPrice: acc.totalPrice + oneItemPrice,
  //       };
  //     },
  //     {
  //       totalItems: 0,
  //       totalPrice: 0,
  //     },
  //   );

  //   return result;
  // };

  // const { totalItems, totalPrice } = calculateTotal();

  return (
    <ContentLayout>
      <BackButtonContainer>
        <BackButton />
      </BackButtonContainer>
      <CartHeader>
        <h1>Cart</h1>
      </CartHeader>
      {cartProducts.length > 0 ? (
        <CartContainer>
          <CartList>
            {cartProducts.map((product) => (
              <CartItemPage
                key={product._id}
                product={product}
                setTotalItems={setTotalItems}
              />
            ))}
          </CartList>
          <CartSummary>
            <TotalPrice>
              <p>${totalPrice}</p>
            </TotalPrice>
            <TotalItems>
              <p>Total for {totalItems} items</p>
            </TotalItems>
            <CartCheckout onClick={handleToggle}>
              <p>Checkout</p>
            </CartCheckout>
            {showModal && (
              <CartPageModal
                title="Success!!!"
                content="Your order has been placed successfully."
                actions={
                  <ModalIconClose onClick={handleToggle}>
                    <IconSprite />
                    <Icon spriteName="close" size="16px" fill="#B4BDC3" />
                  </ModalIconClose>
                }
                handleToggle={handleToggle}
              />
            )}
          </CartSummary>
        </CartContainer>
      ) : (
        <CartEmpty>
          <p>Your cart is empty</p>
        </CartEmpty>
      )}
    </ContentLayout>
  );
};
