import { styled } from 'styled-components';
import { pageGridMixin } from '../Mixins';

export const AppLayout = styled.div`
  ${pageGridMixin}
`;
