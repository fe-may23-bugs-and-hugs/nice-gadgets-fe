import { styled } from 'styled-components';

export const ContentLayout = styled.div`
  grid-column: 1 / -1;
`;
