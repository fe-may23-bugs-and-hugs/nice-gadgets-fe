export type Description = {
  title: string;
  text: string;
};
