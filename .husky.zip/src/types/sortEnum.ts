/* eslint-disable */
export enum SORTING {
  NEWEST = 'year',
  ALPH = 'name',
  CHEAPEST = 'priceDiscount',
}
