/*eslint-disable*/
export enum ORDER {
  ASC = 'asc',
  DESC = 'desc',
}
